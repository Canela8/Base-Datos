const leftArrow = document.querySelector('.left-arrow');
const rightArrow = document.querySelector('.right-arrow');
const librosCont = document.querySelector('.libros-cont');

// Mover hacia la izquierda
leftArrow.addEventListener('click', () => {
    librosCont.scrollBy({
        left: -200, // Ajusta el valor según el tamaño de cada libro
        behavior: 'smooth'
    });
});

// Mover hacia la derecha
rightArrow.addEventListener('click', () => {
    librosCont.scrollBy({
        left: 200, // Ajusta el valor según el tamaño de cada libro
        behavior: 'smooth'
    });
});
//-------------------------------------------------------
const container = document.querySelector(".container");
const btnSignIn = document.getElementById("btn-sign-in");
const btnSignUp = document.getElementById("btn-sign-up");

btnSignIn.addEventListener("click",()=>{
    container.classList.remove("toggle");
});

btnSignUp.addEventListener("click",()=>{
    container.classList.add("toggle");
});

